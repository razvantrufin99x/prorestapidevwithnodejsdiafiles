# Changelog

## Release 3.0.0 (2017-06-05)
 * [BREAKING CHANGE] Not modifying input data (removed internal calling _compact function)

## Release 2.3.1 (2015-01-14)
 * Fixed an issue when a single item array is compacted to an object

## Release 2.3.0 (2015-01-11)
 * Altered addEmbed to accept an array as a second argument

## Release 2.2.0 (2014-08-18)
 * Added insertEmbed method

## Release 2.1.1 (2014-04-25)
 * Fixed IE8 Array.slice() call

## Release 2.1.0 (2014-03-24)
 * Added support to return a default value from getLink() and getEmbed()
