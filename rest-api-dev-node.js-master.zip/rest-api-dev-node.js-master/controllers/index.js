

module.exports = {
	BookSales: require("./booksales"),
	Stores: require("./stores"),
	Employees: require("./employees"),
	ClientReviews: require("./clientreviews"),
	Clients: require("./clients"),
	Books: require("./books"),
	Authors: require("./authors")
}