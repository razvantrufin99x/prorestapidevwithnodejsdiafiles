

module.exports = {
	booksales: require("./booksales")
}